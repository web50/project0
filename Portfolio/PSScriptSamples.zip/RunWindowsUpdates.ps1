﻿#Author: Aaron Voymas
#Date: 1/24/2018
#Purpose: Run Windows Updates, from Powershell
#Dependencies: PSWindowsUpdate module; *note* if the module is not installed, this script will install it.
#ExecutionPolicy: To run the updates, the execution policy of Restricted will block it, so the script
# will change any Restricted execution policy, into a remote signed policy.
#This must be run from an elevated Powershell.

# Check for the PSWindowsUpdate module
if(Get-Module -ListAvailable -Name PSWindowsUpdate)
{
    Write-Host "Module already installed"
}
else
{
    Write-Host "Installing Windows Update Module"
    Install-Module PSWindowsUpdate -Confirm
}

# Check the current Execution Policy
$Policy = "Restricted"
if((Get-ExecutionPolicy) -eq $Policy)
{
    Write-Host "Changing execution policy from restricted to remote-signed"
    Set-ExecutionPolicy -RemoteSigned -Force
}
else
{
    Write-Host "Execution policy does not need to be changed"
}

# Run the updates
Import-Module PSWindowsUpdate
Get-WUList  ## checks for the available updates
Install-WindowsUpdate ## installs the updates
Pause