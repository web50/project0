﻿## Author:  Aaron Voymas
## Use this script to export high priority log files to .CSV format.  This will run with current
## user priviliges.  Afterwards, you can run the Clear-EventLog cmdlet to clear the logs.
## *NOTE*: Date Formatting on older versions of powershell may result in odd naming conventions
## *NOTE*: After the logs are exported, place them in a zip file, and change the permissions so that
##         you will be able to access them on the computer you move them to, to read them.
$date = Get-Date -Format FileDate ## Store the path-friendly date
$appLog = "applog$date" ## Create the filename strings
$sysLog = "syslog$date"
$secLog = "seclog$date"
$user = $Env:USERNAME
$filepath = "C:\Users\$user\Desktop"

## Create spreadsheets of the errors and warnings
Get-EventLog -LogName Application -EntryType Error,Warning | Export-CSV -Path $filepath\$appLog.csv

Get-EventLog -LogName System -EntryType Error,Warning | Export-CSV -Path $filepath\$sysLog.csv

Get-EventLog -LogName Security -EntryType FailureAudit | Export-CSV -Path $filepath\$secLog.csv